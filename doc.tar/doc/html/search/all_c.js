var searchData=
[
  ['validity',['validity',['../classTUPLE.html#a15e6fe7915b00b6fce4842630dc3bbb0',1,'TUPLE']]]
];
