var searchData=
[
  ['registerdevice',['registerDevice',['../classSRCCELL.html#a0b41dd4b175c06ce862c4fc3d5ba10a2',1,'SRCCELL']]],
  ['runstreamfactory',['runSTREAMFACTORY',['../classFACTORYBUILDER.html#a47d4f78877f1fa2a6b4bc00a4c5c4471',1,'FACTORYBUILDER']]]
];
