var searchData=
[
  ['tuple',['TUPLE',['../classTUPLE.html#aed245ec6fb2cd8e94cd9bc1e7eb4a86d',1,'TUPLE::TUPLE(char *data, ushort nLen, ushort seq, int fd)'],['../classTUPLE.html#a00b079f9d403adb63356880c62d48e22',1,'TUPLE::TUPLE(ushort nLen, int fd, int type)'],['../classTUPLE.html#ac92a492d3f8a793fe02fe364244c34af',1,'TUPLE::TUPLE(char *packet, bool isSpecial)']]]
];
