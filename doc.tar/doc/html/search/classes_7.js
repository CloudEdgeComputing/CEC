var searchData=
[
  ['tuple',['TUPLE',['../classTUPLE.html',1,'']]]
];
