var indexSectionsWithContent =
{
  0: "bcdfglmprstuvw",
  1: "bcdfmpstuw",
  2: "bcdfstu",
  3: "bcdglmprstuv",
  4: "bct"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Pages"
};

