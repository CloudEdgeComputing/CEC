var searchData=
[
  ['cloud_20edge_20computing_28cec_29_20framework',['Cloud Edge Computing(CEC) framework',['../index.html',1,'']]]
];
