var searchData=
[
  ['cell',['CELL',['../classCELL.html',1,'CELL'],['../classCELL.html#a266db2529e185e3f0f653f874c783c54',1,'CELL::CELL(PIPE *inpipe, PIPE *outpipe, ushort count, STREAMFACTORY *parent, uint XIXO)'],['../classCELL.html#a8dcb65b2c6869145de9cf5056d7fe356',1,'CELL::CELL(PIPE *inoutpipe, ushort count, STREAMFACTORY *parent, uint XIXO)'],['../classCELL.html#ae82291f0f5dd18ef2ba31e6af1a74e09',1,'CELL::CELL(PIPE *inpipe, list&lt; PIPE * &gt; *outpipelist, ushort count, STREAMFACTORY *parent, uint XIXO)'],['../classCELL.html#a2fad68b40d0adbecfee691618c256518',1,'CELL::CELL(list&lt; PIPE * &gt; *outpipelist, ushort count, STREAMFACTORY *parent, uint XIXO)'],['../classCELL.html#a42a40e06fa704cbe13e1a5fbfaaaafdd',1,'CELL::CELL(list&lt; PIPE * &gt; *inpipelist, list&lt; PIPE * &gt; *outpipelist, ushort count, STREAMFACTORY *parent, uint XIXO)']]],
  ['cell_2eh',['CELL.h',['../CELL_8h.html',1,'']]],
  ['client',['CLIENT',['../structCLIENT.html',1,'']]],
  ['conndata',['CONNDATA',['../structCONNDATA.html',1,'']]],
  ['connection',['CONNECTION',['../classCONNECTION.html',1,'']]],
  ['cloud_20edge_20computing_28cec_29_20framework',['Cloud Edge Computing(CEC) framework',['../index.html',1,'']]]
];
