var searchData=
[
  ['basiccell',['BASICCELL',['../classBASICCELL.html',1,'BASICCELL'],['../classBASICCELL.html#a0058bee3f5c99d05c321b47cb803badc',1,'BASICCELL::BASICCELL(PIPE *inpipe, PIPE *outpipe, ushort count, FUNC func, STREAMFACTORY *parent)'],['../classBASICCELL.html#a9e173d89e7c3c2b2513cb7f6d8f455b8',1,'BASICCELL::BASICCELL(PIPE *inpipe, list&lt; PIPE * &gt; *outpipelist, ushort count, FUNC func, STREAMFACTORY *parent)']]],
  ['basiccell_2eh',['BASICCELL.h',['../BASICCELL_8h.html',1,'']]],
  ['bug_20list',['Bug List',['../bug.html',1,'']]]
];
